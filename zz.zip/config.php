<?php

// ** Database settings** //

/** The name of the database  */
define('DB_NAME', 'zennet_mramar');

/** Database username */
define('DB_USER', 'zennet_mrgir');

/** Database password */
define('DB_PASSWORD', 'YqFJWf6jS2kWbpbHwrsH');

/** Database COLLATE  */
define('COLLATE', 'utf8mb4_0900_ai_ci');

/** AMARGIR_URL  */
define('AMARGIR_URL', 'https://zendegibaayeha.ir/amargir/');


