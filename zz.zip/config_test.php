<?php

// ** Database settings** //

/** The name of the database  */
define('DB_NAME', 'amargir');

/** Database username */
define('DB_USER', 'root');

/** Database password */
define('DB_PASSWORD', '');

/** Database Table  */
define('COLLATE', 'utf8mb4_0900_ai_ci');

/** AMARGIR_URL  */
define('AMARGIR_URL', 'http://amargir.test/');


